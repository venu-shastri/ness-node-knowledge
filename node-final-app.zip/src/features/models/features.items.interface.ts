import {Feature} from './feature.interface'

export interface Features{
    [key:number]:Feature;
}